package com.gamje.pagos.controller;

import com.gamje.pagos.dto.PagoDetalleDTO;
import com.gamje.pagos.model.Pago;
import com.gamje.pagos.service.PagoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pagos")
public class PagoController {

    private final PagoService pagoService;

    public PagoController(PagoService pagoService) {
        this.pagoService = pagoService;
    }

    @PostMapping
    public ResponseEntity<?> crearPago(@RequestBody Pago pago) {
        try {
            return ResponseEntity.ok(pagoService.registrarPago(pago));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<List<Pago>> listar() {
        return ResponseEntity.ok(pagoService.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> porId(@PathVariable int id) {
        return pagoService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable int id) {
        pagoService.eliminar(id);
        return ResponseEntity.ok("Pago eliminado.");
    }

    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<Pago>> pagosPorUsuario(@PathVariable int idUsuario) {
        return ResponseEntity.ok(pagoService.obtenerPorUsuario(idUsuario));
    }

    @GetMapping("/curso/{idCurso}")
    public ResponseEntity<List<Pago>> pagosPorCurso(@PathVariable int idCurso) {
        return ResponseEntity.ok(pagoService.obtenerPorCurso(idCurso));
    }
    @GetMapping("/detalle/{id}")
    public ResponseEntity<?> obtenerDetalle(@PathVariable int id) {
        try {
            return ResponseEntity.ok(pagoService.obtenerDetallePorId(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    @GetMapping("/detalles")
    public ResponseEntity<List<PagoDetalleDTO>> obtenerTodosConDetalles() {
        return ResponseEntity.ok(pagoService.obtenerTodosConDetalles());
    }
}
