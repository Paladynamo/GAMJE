package com.gamje.evaluaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvaluacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvaluacionesApplication.class, args);
	}

}
