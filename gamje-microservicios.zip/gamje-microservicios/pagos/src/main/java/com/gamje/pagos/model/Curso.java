package com.gamje.pagos.model;

import lombok.Data;

@Data
public class Curso {
    private int id;
    private String nombre;
    private String descripcion;
    private String docente;
    private String duracion;
}