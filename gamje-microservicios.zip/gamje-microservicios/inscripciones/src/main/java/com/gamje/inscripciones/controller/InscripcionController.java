package com.gamje.inscripciones.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gamje.inscripciones.dto.InscripcionDetalleDTO;
import com.gamje.inscripciones.model.Inscripcion;
import com.gamje.inscripciones.service.InscripcionService;

@RestController
@RequestMapping("/inscripciones")
public class InscripcionController {

    private final InscripcionService inscripcionService;

    public InscripcionController(InscripcionService inscripcionService) {
        this.inscripcionService = inscripcionService;
    }

    // Crear inscripción
    @PostMapping
    public ResponseEntity<?> crearInscripcion(@RequestBody Inscripcion inscripcion) {
        try {
            Inscripcion nueva = inscripcionService.guardar(inscripcion);
            return ResponseEntity.ok(nueva);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    // Obtener todas
    @GetMapping
    public ResponseEntity<List<Inscripcion>> obtenerTodas() {
        return ResponseEntity.ok(inscripcionService.obtenerTodas());
    }

    // Obtener por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerInscripcionPorId(@PathVariable int id) {
        Optional<Inscripcion> inscripcion = inscripcionService.obtenerPorId(id);
        return inscripcion.map(ResponseEntity::ok)
                          .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Eliminar
    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarInscripcion(@PathVariable int id) {
        inscripcionService.eliminar(id);
        return ResponseEntity.ok("Inscripción eliminada correctamente.");
    }

    // Filtrar por usuario
    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<Inscripcion>> obtenerPorUsuario(@PathVariable int idUsuario) {
        return ResponseEntity.ok(inscripcionService.obtenerPorUsuario(idUsuario));
    }

    // Filtrar por curso
    @GetMapping("/curso/{idCurso}")
    public ResponseEntity<List<Inscripcion>> obtenerPorCurso(@PathVariable int idCurso) {
        return ResponseEntity.ok(inscripcionService.obtenerPorCurso(idCurso));
    }

    // 🔎 Consultas con detalles (DTO)
    @GetMapping("/detalles")
    public ResponseEntity<List<InscripcionDetalleDTO>> obtenerConDetalles() {
        return ResponseEntity.ok(inscripcionService.obtenerTodasConDetalles());
    }

    @GetMapping("/detalle/{id}")
    public ResponseEntity<?> obtenerDetalleInscripcion(@PathVariable int id) {
        try {
            InscripcionDetalleDTO detalle = inscripcionService.obtenerDetalleInscripcion(id);
            return ResponseEntity.ok(detalle);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    //ARREGLAR PARA; Obtener el id y mostrar solamente 1, el metodo de abajo cambie aqui el private por public
    @GetMapping("/detalle/por-usuario/{idUsuario}")
    public ResponseEntity<List<InscripcionDetalleDTO>> obtenerDetallePorUsuario(@PathVariable int idUsuario) {
        return ResponseEntity.ok(inscripcionService.obtenerDetallePorUsuario(idUsuario));
    }
    //ARREGLAR PARA; Obtener el id y mostrar solamente 1, el metodo de abajo
    @GetMapping("/detalle/por-curso/{idCurso}")
    public ResponseEntity<List<InscripcionDetalleDTO>> obtenerDetallePorCurso(@PathVariable int idCurso) {
        return ResponseEntity.ok(inscripcionService.obtenerDetallePorCurso(idCurso));
    }
}
