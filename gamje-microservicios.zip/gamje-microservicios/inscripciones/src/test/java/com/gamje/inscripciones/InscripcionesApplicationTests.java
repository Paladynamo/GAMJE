package com.gamje.inscripciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InscripcionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
